/api/api &
node /app/server.js &
wait -n
