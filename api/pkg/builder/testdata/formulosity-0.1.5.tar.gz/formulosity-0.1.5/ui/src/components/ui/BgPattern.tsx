export const BgPattern = () => {
  return (
    <div className="background">
      <div className="background-screen">
        <div className="background-fill"></div>
      </div>
    </div>
  )
}
