export const siteConfig = {
  name: 'Formulosity',
  description:
    'Formulosity is a Surveys as Code platform that empowers users to craft and deploy sophisticated surveys with the ease and flexibility of writing code.',
}
