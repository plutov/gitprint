'use client'

export default function SurveyNotFound() {
  return (
    <div className="flex m-auto justify-center items-center gap-4">
      <h1 className="h1">Survey not found</h1>
    </div>
  )
}
